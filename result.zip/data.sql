-- MySQL dump 10.16  Distrib 10.1.26-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.1.26-MariaDB-0+deb9u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dbo.Product`
--

DROP TABLE IF EXISTS `dbo.Product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbo.Product` (
  `ProductId` tinyint(4) DEFAULT NULL,
  `UserId` smallint(6) DEFAULT NULL,
  `ProductName` varchar(9) DEFAULT NULL,
  `Category` varchar(11) DEFAULT NULL,
  `ProductCode` varchar(6) DEFAULT NULL,
  `ProductPrice` decimal(6,1) DEFAULT NULL,
  `Description` varchar(52) DEFAULT NULL,
  `ProductStatus` varchar(12) DEFAULT NULL,
  `Discount` decimal(3,1) DEFAULT NULL,
  `ProductImage` varchar(22) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo.Product`
--

LOCK TABLES `dbo.Product` WRITE;
/*!40000 ALTER TABLE `dbo.Product` DISABLE KEYS */;
INSERT INTO `dbo.Product` VALUES (13,1011,'Computer','Electronics','AS1010',12000.0,'Computer with 4 GB Ram and having i5 Intel Processor','In Stock',5.0,'~/Images/computer.jpg'),(14,1011,'Bournvita',' Grocery','BS1011',500.0,'It is Health Drink of chocolate flavour','In Stock',2.0,'~/Images/BournVita.jpg'),(15,1011,'Shirt','Garments','SH1901',800.0,'It is pure cotton shirt.','Out of Stock',10.0,'~/Images/shirt.jpg');
/*!40000 ALTER TABLE `dbo.Product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo.User`
--

DROP TABLE IF EXISTS `dbo.User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbo.User` (
  `UserId` smallint(6) DEFAULT NULL,
  `Name` varchar(8) DEFAULT NULL,
  `EmailId` varchar(27) DEFAULT NULL,
  `Contact` bigint(20) DEFAULT NULL,
  `Address` varchar(23) DEFAULT NULL,
  `City` varchar(9) DEFAULT NULL,
  `State` varchar(7) DEFAULT NULL,
  `Country` varchar(5) DEFAULT NULL,
  `ZipCode` mediumint(9) DEFAULT NULL,
  `Password` varchar(12) DEFAULT NULL,
  `EmailVerified` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo.User`
--

LOCK TABLES `dbo.User` WRITE;
/*!40000 ALTER TABLE `dbo.User` DISABLE KEYS */;
INSERT INTO `dbo.User` VALUES (1010,'Khushboo','raghanikhushboo17@gmail.com',8963652365,'Block No: 780/6','Ahmedabad','Gujarat','India',382475,'Khushboo@123',0),(1011,'Khushboo','raghanikhushboo52@gmail.com',989898034,'Sardarnagar, Ahmedabad.','Ahmedabad','Gujarat','India',382475,'Khushboo@123',1);
/*!40000 ALTER TABLE `dbo.User` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-22 15:20:25
