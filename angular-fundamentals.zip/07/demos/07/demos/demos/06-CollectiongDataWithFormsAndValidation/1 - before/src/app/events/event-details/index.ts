export * from './event-route-activator.service'
export * from './event-details.component'
